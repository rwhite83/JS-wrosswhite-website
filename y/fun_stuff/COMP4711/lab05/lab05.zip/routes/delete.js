let express = require('express')
let app = express();
// let bodyParser = require('body-parser');
let path = require('path');
// let http = require('http');
var fs = require('fs');
// let mod = require('../test_wubb');
const router = express.Router();


console.log("test miracle")